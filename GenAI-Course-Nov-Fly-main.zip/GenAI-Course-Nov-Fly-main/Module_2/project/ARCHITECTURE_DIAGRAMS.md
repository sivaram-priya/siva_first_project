# 🏗️ E-Commerce Product Onboarding System - Architecture Diagrams

## 📋 Table of Contents

1. [High-Level Architecture](#1-high-level-architecture)
2. [Detailed Component Architecture](#2-detailed-component-architecture)
3. [Data Flow Architecture](#3-data-flow-architecture)
4. [Network Architecture](#4-network-architecture)
5. [Event-Driven Flow](#5-event-driven-flow)
6. [Database Architecture](#6-database-architecture)
7. [Error Handling Architecture](#7-error-handling-architecture)
8. [Security Architecture](#8-security-architecture)

---

## 1. High-Level Architecture

### System Overview
```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    PRODUCT ONBOARDING SYSTEM - HIGH LEVEL                   │
└─────────────────────────────────────────────────────────────────────────────┘

                                 ┌──────────────┐
                                 │   VENDOR     │
                                 │  (External)  │
                                 └──────┬───────┘
                                        │
                                        │ Uploads CSV
                                        ↓
                        ┌───────────────────────────────┐
                        │       AWS CLOUD (VPC)         │
                        │                               │
                        │  ┌─────────────────────────┐  │
                        │  │      S3 BUCKET          │  │
                        │  │  uploads/ | errors/     │  │
                        │  └──────────┬──────────────┘  │
                        │             │                 │
                        │             │ Triggers        │
                        │             ↓                 │
                        │  ┌─────────────────────────┐  │
                        │  │  LAMBDA FUNCTIONS (3)   │  │
                        │  │  ┌─────────────────┐    │  │
                        │  │  │  CSV Parser     │    │  │
                        │  │  └────────┬────────┘    │  │
                        │  │           │             │  │
                        │  │  ┌────────▼────────┐    │  │
                        │  │  │  Validator      │    │  │
                        │  │  └────────┬────────┘    │  │
                        │  │           │             │  │
                        │  │  ┌────────▼────────┐    │  │
                        │  │  │ Error Processor │    │  │
                        │  │  └─────────────────┘    │  │
                        │  └─────────────────────────┘  │
                        │             │                 │
                        │             │ Stores Data     │
                        │             ↓                 │
                        │  ┌─────────────────────────┐  │
                        │  │     DATABASES           │  │
                        │  │  ┌──────────────────┐   │  │
                        │  │  │ DynamoDB         │   │  │
                        │  │  │ (Temporary)      │   │  │
                        │  │  └──────────────────┘   │  │
                        │  │  ┌──────────────────┐   │  │
                        │  │  │ RDS PostgreSQL   │   │  │
                        │  │  │ (Permanent)      │   │  │
                        │  │  └──────────────────┘   │  │
                        │  └─────────────────────────┘  │
                        │             │                 │
                        │             │ Notifies        │
                        │             ↓                 │
                        │  ┌─────────────────────────┐  │
                        │  │   SNS → EMAIL           │  │
                        │  └─────────────────────────┘  │
                        │                               │
                        └───────────────────────────────┘
                                        │
                                        │ Email
                                        ↓
                                 ┌──────────────┐
                                 │    VENDOR    │
                                 │ (Receives    │
                                 │ Notification)│
                                 └──────────────┘
```

### Key Components
- **Entry Point**: S3 Bucket (CSV upload)
- **Processing**: 3 Lambda Functions (Serverless compute)
- **Storage**: DynamoDB (staging) + RDS (catalog)
- **Communication**: SQS (queuing) + SNS (notifications)
- **Security**: Secrets Manager, VPC, IAM

---

## 2. Detailed Component Architecture

### Complete System with All AWS Services
```
┌────────────────────────────────────────────────────────────────────────────────────────────┐
│                         DETAILED COMPONENT ARCHITECTURE                                     │
└────────────────────────────────────────────────────────────────────────────────────────────┘

                                    ┌─────────────┐
                                    │   VENDOR    │
                                    └──────┬──────┘
                                           │
                                           │ 1. Upload CSV
                                           ↓
                    ┌──────────────────────────────────────────────────────┐
                    │                    AWS ACCOUNT                        │
                    │                                                       │
                    │  ┌─────────────────────────────────────────────────┐ │
                    │  │            AMAZON S3 BUCKET                      │ │
                    │  │  ecommerce-product-uploads-{account-id}         │ │
                    │  │                                                  │ │
                    │  │  📁 uploads/                                     │ │
                    │  │     └─ VEND001/                                  │ │
                    │  │        └─ VEND001_20241221_103045.csv           │ │
                    │  │                                                  │ │
                    │  │  📁 errors/                                      │ │
                    │  │     └─ VEND001/                                  │ │
                    │  │        └─ UPLOAD_20241221_103045_errors.csv     │ │
                    │  │                                                  │ │
                    │  │  [Versioning: ON] [Encryption: AES-256]         │ │
                    │  └──────────────────┬───────────────────────────────┘ │
                    │                     │                                  │
                    │                     │ 2. S3 Event Notification         │
                    │                     │    (ObjectCreated:*)              │
                    │                     ↓                                  │
                    │  ┌─────────────────────────────────────────────────┐ │
                    │  │         AWS LAMBDA: csv-parser                  │ │
                    │  │  ┌────────────────────────────────────────────┐ │ │
                    │  │  │  Container Image (from ECR)                │ │ │
                    │  │  │  • Python 3.11                             │ │ │
                    │  │  │  • boto3, psycopg2                         │ │ │
                    │  │  │  • Memory: 512 MB                          │ │ │
                    │  │  │  • Timeout: 5 min                          │ │ │
                    │  │  │                                            │ │ │
                    │  │  │  Process:                                  │ │ │
                    │  │  │  1. Download CSV from S3                  │ │ │
                    │  │  │  2. Verify vendor in RDS ────────────┐    │ │ │
                    │  │  │  3. Parse CSV rows                   │    │ │ │
                    │  │  │  4. Batch insert to DynamoDB         │    │ │ │
                    │  │  └────────────────────┬───────────────────────┘ │ │
                    │  │                       │                           │ │
                    │  │  [VPC Enabled] [IAM Role: csv-parser-role]       │ │
                    │  └───────────────────────┼───────────────────────────┘ │
                    │                          │                              │
                    │                          │ 3. Batch Write               │
                    │                          ↓                              │
                    │  ┌─────────────────────────────────────────────────┐ │
                    │  │       AMAZON DYNAMODB: UploadRecords            │ │
                    │  │                                                  │ │
                    │  │  Table Schema:                                   │ │
                    │  │  • PK: upload_id (String)                       │ │
                    │  │  • SK: record_id (String)                       │ │
                    │  │  • Attributes: vendor_id, product_data, status  │ │
                    │  │                                                  │ │
                    │  │  Indexes:                                        │ │
                    │  │  • GSI: VendorIndex (vendor_id)                 │ │
                    │  │                                                  │ │
                    │  │  DynamoDB Streams: ENABLED (NEW_IMAGE)          │ │
                    │  │  Billing: On-Demand (Pay per request)           │ │
                    │  └──────────────────┬───────────────────────────────┘ │
                    │                     │                                  │
                    │                     │ 4. Stream Trigger                │
                    │                     │    (INSERT events)                │
                    │                     ↓                                  │
                    │  ┌─────────────────────────────────────────────────┐ │
                    │  │      AWS LAMBDA: product-validator              │ │
                    │  │  ┌────────────────────────────────────────────┐ │ │
                    │  │  │  Container Image (from ECR)                │ │ │
                    │  │  │  • Python 3.11 + psycopg2                  │ │ │
                    │  │  │  • Memory: 512 MB                          │ │ │
                    │  │  │  • Timeout: 5 min                          │ │ │
                    │  │  │                                            │ │ │
                    │  │  │  Process:                                  │ │ │
                    │  │  │  1. Receive batch (100 records)           │ │ │
                    │  │  │  2. For each record:                      │ │ │
                    │  │  │     • Run 7 validation rules              │ │ │
                    │  │  │     • Query RDS for constraints ──────┐   │ │ │
                    │  │  │     • IF VALID: Insert to RDS  ───────┼─┐ │ │ │
                    │  │  │     • IF INVALID: Send to SQS ────┐   │ │ │ │ │
                    │  │  │  3. Update DynamoDB status        │   │ │ │ │ │
                    │  │  └───────────────────────────────────┼───┼───┘ │ │
                    │  │                                      │   │       │ │
                    │  │  [VPC Enabled] [IAM Role: validator-role]│       │ │
                    │  │  [Connection Pooling: Enabled]       │   │       │ │
                    │  └──────────────────────────────────────┼───┼───────┘ │
                    │                                         │   │          │
                    │     ┌───────────────────────────────────┘   │          │
                    │     │                                       │          │
                    │     │ 5a. Valid Products                    │ 5b. Errors│
                    │     ↓                                       ↓          │
                    │  ┌──────────────────────┐      ┌────────────────────┐ │
                    │  │  RDS PostgreSQL      │      │   AMAZON SQS       │ │
                    │  │  ecommerce-db        │      │                    │ │
                    │  │                      │      │  Queue:            │ │
                    │  │  Tables:             │      │  product-          │ │
                    │  │  • products ✓        │      │  validation-       │ │
                    │  │  • vendors           │      │  errors            │ │
                    │  │  • upload_history    │      │                    │ │
                    │  │  • product_categories│      │  [Visibility: 5min]│ │
                    │  │  • validation_errors │      │  [Retention: 4 day]│ │
                    │  │                      │      │                    │ │
                    │  │  [VPC: Private]      │      │  DLQ: Enabled      │ │
                    │  │  [Encrypted: Yes]    │      │  [Max Receive: 3]  │ │
                    │  └──────────────────────┘      └─────────┬──────────┘ │
                    │            ▲                              │             │
                    │            │                              │             │
                    │            │                              │ 6. Batch    │
                    │            │                              │    Trigger  │
                    │            │                              │    (10 msg, │
                    │            │                              │     30 sec) │
                    │            │                              ↓             │
                    │            │          ┌─────────────────────────────┐  │
                    │            │          │  AWS LAMBDA:                │  │
                    │            │          │  error-processor            │  │
                    │            │          │  ┌────────────────────────┐ │  │
                    │            │          │  │ Container (from ECR)   │ │  │
                    │            │          │  │ • Python 3.11          │ │  │
                    │            │          │  │ • Memory: 256 MB       │ │  │
                    │            │          │  │                        │ │  │
                    │            │          │  │ Process:               │ │  │
                    │            │          │  │ 1. Parse SQS messages  │ │  │
                    │            │          │  │ 2. Group by upload_id  │ │  │
                    │            │          │  │ 3. Generate error CSV  │ │  │
                    │            └──────────┼──│ 4. Upload to S3  ──────┼─┼──┘
                    │     Read credentials  │  │ 5. Update RDS          │ │
                    │                       │  │ 6. Check completion    │ │
                    │                       │  │ 7. Trigger SNS ────┐   │ │
                    │                       │  └────────────────────┼───┘ │
                    │                       │                       │     │
                    │                       │  [VPC Enabled]        │     │
                    │                       └───────────────────────┼─────┘
                    │                                               │
                    │                                               │ 7. Publish
                    │       ┌───────────────────────────────────────┘
                    │       │
                    │       ↓
                    │  ┌─────────────────────────────────────────────────┐
                    │  │          AMAZON SNS TOPIC                        │
                    │  │  product-upload-notifications                    │
                    │  │                                                   │
                    │  │  Subscriptions:                                  │
                    │  │  • Email: vendor@example.com ✓ (Confirmed)      │
                    │  │  • Email: support@company.com ✓ (Confirmed)     │
                    │  │                                                   │
                    │  │  Message Format:                                 │
                    │  │  • Subject: Upload Complete (93.5% Success)      │
                    │  │  • Body: Statistics + Error CSV link             │
                    │  └──────────────────┬───────────────────────────────┘
                    │                     │
                    │  ┌──────────────────────────────────────────────────┐
                    │  │         SUPPORTING SERVICES                       │
                    │  │                                                   │
                    │  │  ┌────────────────────────────────────────────┐  │
                    │  │  │  AWS SECRETS MANAGER                       │  │
                    │  │  │  ecommerce/rds/credentials                 │  │
                    │  │  │  • username, password, host, port, dbname  │  │
                    │  │  │  • KMS Encrypted                           │  │
                    │  │  │  • Client-side caching (1 hour)            │  │
                    │  │  └────────────────────────────────────────────┘  │
                    │  │                                                   │
                    │  │  ┌────────────────────────────────────────────┐  │
                    │  │  │  AMAZON ECR (Container Registry)           │  │
                    │  │  │  • csv-parser-lambda:latest                │  │
                    │  │  │  • product-validator-lambda:latest         │  │
                    │  │  │  • error-processor-lambda:latest           │  │
                    │  │  │  [Image Scanning: Enabled]                 │  │
                    │  │  └────────────────────────────────────────────┘  │
                    │  │                                                   │
                    │  │  ┌────────────────────────────────────────────┐  │
                    │  │  │  AMAZON CLOUDWATCH                         │  │
                    │  │  │  • Log Groups: /aws/lambda/{function}      │  │
                    │  │  │  • Metrics: Custom + Lambda metrics        │  │
                    │  │  │  • Alarms: Error rate, Duration            │  │
                    │  │  └────────────────────────────────────────────┘  │
                    │  │                                                   │
                    │  │  ┌────────────────────────────────────────────┐  │
                    │  │  │  AWS IAM (Identity & Access Management)    │  │
                    │  │  │  • Lambda execution roles (3)              │  │
                    │  │  │  • Service policies (least privilege)      │  │
                    │  │  │  • Resource-based policies                 │  │
                    │  │  └────────────────────────────────────────────┘  │
                    │  └───────────────────────────────────────────────────┘
                    │                     │
                    └─────────────────────┼──────────────────────────────────┘
                                          │ 8. Email
                                          ↓
                                   ┌──────────────┐
                                   │    VENDOR    │
                                   │  (Receives)  │
                                   │              │
                                   │  📧 Email:   │
                                   │  • Stats     │
                                   │  • Download  │
                                   │    link      │
                                   └──────────────┘
```

---

## 3. Data Flow Architecture

### Step-by-Step Data Journey
```
┌────────────────────────────────────────────────────────────────────────────────┐
│                           DATA FLOW ARCHITECTURE                                │
└────────────────────────────────────────────────────────────────────────────────┘

STEP 1: CSV UPLOAD
═══════════════════════════════════════════════════════════════════════════════
                    Vendor's Computer
                          │
                          │ [HTTP PUT]
                          │ VEND001_products.csv (5 MB, 1000 rows)
                          ↓
                    ┌─────────────┐
                    │   S3 Bucket │
                    │             │
                    │  Object:    │
                    │  Key: uploads/VEND001/VEND001_products.csv              │
                    │  Size: 5 MB                                              │
                    │  ETag: d41d8cd98f00b204e9800998ecf8427e                 │
                    │  Storage Class: STANDARD                                 │
                    │  Encryption: AES-256                                     │
                    └─────────────┘
                          │
                          │ [S3 Event: ObjectCreated:Put]
                          │
                          ↓

STEP 2: CSV PARSING (Lambda: csv-parser)
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────────┐
                    │  CSV Parser Lambda Execution         │
                    │                                      │
                    │  T+0ms:   Lambda invoked            │
                    │  T+10ms:  Download CSV from S3      │
                    │           ├─ GetObject API call      │
                    │           └─ StreamingBody (5 MB)   │
                    │                                      │
                    │  T+500ms: Query RDS                  │
                    │           SELECT * FROM vendors      │
                    │           WHERE vendor_id='VEND001'  │
                    │           Result: ✓ Active vendor    │
                    │                                      │
                    │  T+600ms: Insert upload_history      │
                    │           INSERT INTO upload_history │
                    │           (upload_id, vendor_id,     │
                    │            file_name, total_records) │
                    │           VALUES ('UPLOAD_001',      │
                    │                   'VEND001',         │
                    │                   'VEND...csv', 1000)│
                    │                                      │
                    │  T+700ms: Parse CSV                  │
                    │           DictReader processes rows  │
                    │           Row 1 → Dict               │
                    │           Row 2 → Dict               │
                    │           ... (1000 rows)            │
                    │                                      │
                    │  T+2000ms: Batch insert DynamoDB     │
                    │            Batch 1: Rows 1-25        │
                    │            Batch 2: Rows 26-50       │
                    │            ... (40 batches total)    │
                    │                                      │
                    │  T+2500ms: Complete ✓                │
                    │            Duration: 2.5 seconds     │
                    │            Memory: 256 MB used       │
                    └──────────────────────────────────────┘
                          │
                          │ [1000 DynamoDB items inserted]
                          ↓

STEP 3: DYNAMODB STORAGE (Temporary Staging)
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────────┐
                    │      DynamoDB: UploadRecords         │
                    │                                      │
                    │  Item 1:                             │
                    │  {                                   │
                    │    upload_id: "UPLOAD_001",         │
                    │    record_id: "REC_00001",          │
                    │    vendor_id: "VEND001",            │
                    │    row_number: 1,                   │
                    │    status: "pending_validation",    │
                    │    product_data: {                  │
                    │      vendor_product_id: "PROD001",  │
                    │      product_name: "Wireless Mouse",│
                    │      sku: "SKU-001",                │
                    │      price: 19.99,                  │
                    │      stock_quantity: 150            │
                    │    }                                 │
                    │  }                                   │
                    │                                      │
                    │  ... (1000 items)                    │
                    │                                      │
                    │  DynamoDB Streams:                   │
                    │  ├─ 1000 INSERT events captured      │
                    │  ├─ StreamViewType: NEW_IMAGE        │
                    │  └─ Batched for Lambda trigger       │
                    └──────────────────────────────────────┘
                          │
                          │ [Stream Event: 1000 records, batched to 10]
                          ↓

STEP 4: VALIDATION (Lambda: product-validator) - 10 Invocations
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────────┐
                    │  Validator Lambda - Batch 1 (100 records) │
                    │                                      │
                    │  For Record 1 (Row 1):               │
                    │                                      │
                    │  ✓ Required fields present           │
                    │  ✓ Price: 19.99 (valid range)        │
                    │  ✓ Stock: 150 (valid range)          │
                    │  ✓ Field lengths OK                  │
                    │  ✓ Category: "Electronics" (exists)  │
                    │    ├─ SELECT FROM product_categories │
                    │    └─ Result: ✓ Found                │
                    │  ✓ SKU unique: "SKU-001"             │
                    │    ├─ SELECT FROM products           │
                    │    │   WHERE sku='SKU-001'            │
                    │    └─ Result: 0 rows (unique!)       │
                    │  ✓ Vendor product ID unique          │
                    │    ├─ SELECT FROM products           │
                    │    │   WHERE vendor_id='VEND001'      │
                    │    │   AND vendor_product_id='PROD001'│
                    │    └─ Result: 0 rows (unique!)       │
                    │                                      │
                    │  RESULT: VALID ✓                     │
                    │                                      │
                    │  Action:                             │
                    │  1. INSERT INTO products             │
                    │     (vendor_id, vendor_product_id,   │
                    │      product_name, sku, price, ...)  │
                    │     RETURNING product_id;            │
                    │     Result: product_id = 12345       │
                    │                                      │
                    │  2. UPDATE DynamoDB                  │
                    │     SET status='validated',          │
                    │         processed_at=NOW()           │
                    │     WHERE upload_id='UPLOAD_001'     │
                    │     AND record_id='REC_00001'        │
                    │                                      │
                    │  For Record 15 (Row 15):             │
                    │                                      │
                    │  ✗ Price: -10.00 (INVALID!)          │
                    │                                      │
                    │  RESULT: INVALID ✗                   │
                    │  Error Type: INVALID_PRICE           │
                    │  Error Message: "Price must be >= 0.01"│
                    │                                      │
                    │  Action:                             │
                    │  1. SEND to SQS error queue          │
                    │     Message: {upload_id, record_id,  │
                    │              error_type, message}    │
                    │                                      │
                    │  2. INSERT INTO validation_errors    │
                    │     (upload_id, row_number,          │
                    │      error_type, error_message, ...) │
                    │                                      │
                    │  3. UPDATE DynamoDB                  │
                    │     SET status='error',              │
                    │         error_reason='INVALID_PRICE',│
                    │         error_details='Price...'     │
                    │                                      │
                    │  ... (Processes all 100 in batch)    │
                    │                                      │
                    │  Batch Summary:                      │
                    │  • Total: 100                        │
                    │  • Valid: 95                         │
                    │  • Invalid: 5                        │
                    │  • Duration: 4.5 seconds             │
                    └──────────────────────────────────────┘
                          │
                          │ [After 10 batches: 950 valid, 50 errors]
                          │
                          ├────────────────┬──────────────────┐
                          │                │                  │
                          ↓                ↓                  ↓
                    RDS Products    SQS Queue         DynamoDB Updated
                    (950 inserts)   (50 messages)     (1000 status updated)

STEP 5: ERROR AGGREGATION (SQS Wait Period)
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────────┐
                    │        SQS Error Queue               │
                    │                                      │
                    │  T+0s:  Message 1 arrives (Error 1)  │
                    │  T+0.5s: Message 2 arrives (Error 2) │
                    │  ...                                 │
                    │  T+4s:  Message 50 arrives (Error 50)│
                    │                                      │
                    │  T+30s: Batching window expires      │
                    │         (No new messages for 30s)    │
                    │                                      │
                    │  Trigger Lambda with:                │
                    │  • Batch size: 10 messages           │
                    │  • 5 invocations total (50÷10)       │
                    └──────────────────────────────────────┘
                          │
                          │ [Batch trigger: 10 messages × 5 invocations]
                          ↓

STEP 6: ERROR PROCESSING (Lambda: error-processor)
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────────┐
                    │  Error Processor Lambda              │
                    │                                      │
                    │  T+0ms:   Receive 10 SQS messages    │
                    │                                      │
                    │  T+10ms:  Parse messages             │
                    │           Group by upload_id         │
                    │           {                          │
                    │             'UPLOAD_001': [          │
                    │               {row: 15, error: ...}, │
                    │               {row: 27, error: ...}, │
                    │               ... (10 errors)        │
                    │             ]                        │
                    │           }                          │
                    │                                      │
                    │  T+50ms:  Generate CSV               │
                    │           Row,SKU,Error Type,Message │
                    │           15,SKU-015,INVALID_PRICE,...│
                    │           27,SKU-027,DUPLICATE_SKU,...│
                    │           ... (10 rows)              │
                    │                                      │
                    │  T+200ms: Upload to S3               │
                    │           PutObject:                 │
                    │           errors/VEND001/            │
                    │           UPLOAD_001_errors.csv      │
                    │                                      │
                    │  T+250ms: Generate presigned URL     │
                    │           Expires in: 7 days         │
                    │           URL: https://s3.../errors/...│
                    │                                      │
                    │  T+300ms: Update RDS upload_history  │
                    │           UPDATE upload_history      │
                    │           SET error_file_s3_key=     │
                    │               'errors/VEND001/...'   │
                    │           WHERE upload_id='UPLOAD_001'│
                    │                                      │
                    │  T+350ms: Check completion           │
                    │           SELECT total_records,      │
                    │                  valid_records,      │
                    │                  error_records       │
                    │           FROM upload_history        │
                    │           WHERE upload_id='UPLOAD_001'│
                    │           Result: 1000, 950, 50      │
                    │           Is Complete? 950+50=1000 ✓ │
                    │                                      │
                    │  T+400ms: Trigger SNS                │
                    │           Publish message            │
                    │           Topic: product-upload-...  │
                    │           Subject: Upload Complete   │
                    │           Body: Stats + download link│
                    │                                      │
                    │  T+500ms: Complete ✓                 │
                    │           Duration: 0.5 seconds      │
                    └──────────────────────────────────────┘
                          │
                          │ [SNS Publish]
                          ↓

STEP 7: NOTIFICATION (SNS → Email)
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────────┐
                    │          SNS Topic                   │
                    │  product-upload-notifications        │
                    │                                      │
                    │  Message:                            │
                    │  Subject: Upload Complete (95%)      │
                    │  Body:                               │
                    │    Upload ID: UPLOAD_001             │
                    │    File: VEND001_products.csv        │
                    │    Total: 1000                       │
                    │    Valid: 950 (95%)                  │
                    │    Invalid: 50 (5%)                  │
                    │    Status: PARTIAL                   │
                    │    Download Errors: [presigned URL]  │
                    │                                      │
                    │  Subscribers:                        │
                    │  • vendor@example.com ────────────┐  │
                    │  • support@company.com            │  │
                    └───────────────────────────────────┼──┘
                                                        │
                                                        │ [SES Email Delivery]
                                                        ↓
                                                 ┌──────────────┐
                                                 │    VENDOR    │
                                                 │    INBOX     │
                                                 │              │
                                                 │  📧 New Email│
                                                 │  From: AWS   │
                                                 │  Subject:    │
                                                 │  Upload...   │
                                                 └──────────────┘

FINAL STATE - All Data Locations
═══════════════════════════════════════════════════════════════════════════════

S3 Bucket:
├─ uploads/VEND001/VEND001_products.csv (original)
└─ errors/VEND001/UPLOAD_001_errors.csv (error report)

DynamoDB UploadRecords:
├─ 950 records: status='validated'
└─ 50 records: status='error'

RDS PostgreSQL:
├─ products: 950 new rows (validated catalog)
├─ upload_history: 1 row (total=1000, valid=950, error=50, status='partial')
└─ validation_errors: 50 rows (detailed error tracking)

SQS Queue:
└─ 0 messages (all processed and deleted)

Email:
└─ Delivered to vendor ✓
```

---

## 4. Network Architecture

### VPC and Security Architecture
```
┌────────────────────────────────────────────────────────────────────────────────┐
│                           NETWORK ARCHITECTURE                                  │
│                                                                                 │
│  ┌───────────────────────────────────────────────────────────────────────────┐ │
│  │                        AWS REGION: us-east-1                               │ │
│  │                                                                            │ │
│  │  ┌──────────────────────────────────────────────────────────────────────┐ │ │
│  │  │                    VPC: 10.0.0.0/16                                   │ │ │
│  │  │                                                                       │ │ │
│  │  │  ┌─────────────────────────────────────────────────────────────────┐ │ │ │
│  │  │  │              AVAILABILITY ZONE: us-east-1a                       │ │ │ │
│  │  │  │                                                                  │ │ │ │
│  │  │  │  ┌────────────────────────────────────────────────────────────┐ │ │ │ │
│  │  │  │  │  PUBLIC SUBNET: 10.0.1.0/24                                │ │ │ │ │
│  │  │  │  │                                                             │ │ │ │ │
│  │  │  │  │  ┌──────────────────┐                                      │ │ │ │ │
│  │  │  │  │  │  NAT GATEWAY     │                                      │ │ │ │ │
│  │  │  │  │  │  (For Lambda →   │                                      │ │ │ │ │
│  │  │  │  │  │   Internet)      │                                      │ │ │ │ │
│  │  │  │  │  └────────┬─────────┘                                      │ │ │ │ │
│  │  │  │  │           │                                                │ │ │ │ │
│  │  │  │  └───────────┼────────────────────────────────────────────────┘ │ │ │ │
│  │  │  │              │                                                  │ │ │ │
│  │  │  │  ┌───────────▼────────────────────────────────────────────────┐ │ │ │ │
│  │  │  │  │  PRIVATE SUBNET 1: 10.0.10.0/24                            │ │ │ │ │
│  │  │  │  │                                                             │ │ │ │ │
│  │  │  │  │  ┌─────────────────────────────────────────────────────┐  │ │ │ │ │
│  │  │  │  │  │  LAMBDA FUNCTIONS (3)                               │  │ │ │ │ │
│  │  │  │  │  │                                                      │  │ │ │ │ │
│  │  │  │  │  │  ┌────────────────┐  ┌────────────────┐            │  │ │ │ │ │
│  │  │  │  │  │  │  CSV Parser    │  │  Validator     │            │  │ │ │ │ │
│  │  │  │  │  │  │                │  │                │            │  │ │ │ │ │
│  │  │  │  │  │  │  ENI:          │  │  ENI:          │            │  │ │ │ │ │
│  │  │  │  │  │  │  10.0.10.5     │  │  10.0.10.6     │            │  │ │ │ │ │
│  │  │  │  │  │  │                │  │                │            │  │ │ │ │ │
│  │  │  │  │  │  │  SG:           │  │  SG:           │            │  │ │ │ │ │
│  │  │  │  │  │  │  lambda-sg     │  │  lambda-sg     │            │  │ │ │ │ │
│  │  │  │  │  │  └───────┬────────┘  └───────┬────────┘            │  │ │ │ │ │
│  │  │  │  │  │          │                   │                     │  │ │ │ │ │
│  │  │  │  │  │  ┌───────▼────────┐          │                     │  │ │ │ │ │
│  │  │  │  │  │  │  Error Processor│         │                     │  │ │ │ │ │
│  │  │  │  │  │  │                │          │                     │  │ │ │ │ │
│  │  │  │  │  │  │  ENI:          │          │                     │  │ │ │ │ │
│  │  │  │  │  │  │  10.0.10.7     │          │                     │  │ │ │ │ │
│  │  │  │  │  │  │                │          │                     │  │ │ │ │ │
│  │  │  │  │  │  │  SG: lambda-sg │          │                     │  │ │ │ │ │
│  │  │  │  │  │  └────────────────┘          │                     │  │ │ │ │ │
│  │  │  │  │  │                              │                     │  │ │ │ │ │
│  │  │  │  │  └──────────────────────────────┼─────────────────────┘  │ │ │ │ │
│  │  │  │  │                                 │                        │ │ │ │ │
│  │  │  │  │                                 │ TCP 5432               │ │ │ │ │
│  │  │  │  │                                 ↓ (PostgreSQL)           │ │ │ │ │
│  │  │  │  │  ┌─────────────────────────────────────────────────────┐ │ │ │ │ │
│  │  │  │  │  │  RDS PostgreSQL                                     │ │ │ │ │ │
│  │  │  │  │  │                                                      │ │ │ │ │ │
│  │  │  │  │  │  Endpoint: ecommerce-db.xxxxx.rds.amazonaws.com    │ │ │ │ │ │
│  │  │  │  │  │  Private IP: 10.0.10.100                           │ │ │ │ │ │
│  │  │  │  │  │                                                      │ │ │ │ │ │
│  │  │  │  │  │  Security Group: rds-sg                            │ │ │ │ │ │
│  │  │  │  │  │  Inbound Rules:                                     │ │ │ │ │ │
│  │  │  │  │  │  • Port 5432 from lambda-sg ✓                      │ │ │ │ │ │
│  │  │  │  │  │  • Deny all other                                   │ │ │ │ │ │
│  │  │  │  │  │                                                      │ │ │ │ │ │
│  │  │  │  │  │  [NOT publicly accessible]                          │ │ │ │ │ │
│  │  │  │  │  └──────────────────────────────────────────────────────┘ │ │ │ │ │
│  │  │  │  │                                                             │ │ │ │ │
│  │  │  │  └─────────────────────────────────────────────────────────────┘ │ │ │ │
│  │  │  │                                                                  │ │ │ │
│  │  │  └──────────────────────────────────────────────────────────────────┘ │ │ │
│  │  │                                                                       │ │ │
│  │  │  ┌─────────────────────────────────────────────────────────────────┐ │ │ │
│  │  │  │              AVAILABILITY ZONE: us-east-1b                       │ │ │ │
│  │  │  │                                                                  │ │ │ │
│  │  │  │  ┌────────────────────────────────────────────────────────────┐ │ │ │ │
│  │  │  │  │  PRIVATE SUBNET 2: 10.0.20.0/24                            │ │ │ │ │
│  │  │  │  │                                                             │ │ │ │ │
│  │  │  │  │  ┌─────────────────────────────────────────────────────┐  │ │ │ │ │
│  │  │  │  │  │  RDS PostgreSQL (Standby Replica)                   │  │ │ │ │ │
│  │  │  │  │  │  Private IP: 10.0.20.100                            │  │ │ │ │ │
│  │  │  │  │  │  [Multi-AZ for High Availability]                   │  │ │ │ │ │
│  │  │  │  │  └─────────────────────────────────────────────────────┘  │ │ │ │ │
│  │  │  │  └────────────────────────────────────────────────────────────┘ │ │ │ │
│  │  │  └──────────────────────────────────────────────────────────────────┘ │ │ │
│  │  │                                                                       │ │ │
│  │  │  ┌─────────────────────────────────────────────────────────────────┐ │ │ │
│  │  │  │              INTERNET GATEWAY                                    │ │ │ │
│  │  │  │  (For NAT Gateway connectivity)                                 │ │ │ │
│  │  │  └─────────────────────────────────────────────────────────────────┘ │ │ │
│  │  │                                                                       │ │ │
│  │  └───────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                            │ │
│  │  ┌──────────────────────────────────────────────────────────────────────┐ │ │
│  │  │              VPC ENDPOINTS (AWS PrivateLink)                          │ │ │
│  │  │                                                                       │ │ │
│  │  │  • S3 Endpoint (Gateway)      → Access S3 without internet          │ │ │
│  │  │  • DynamoDB Endpoint (Gateway) → Access DynamoDB without internet    │ │ │
│  │  │  • Secrets Manager Endpoint   → Access Secrets without internet     │ │ │
│  │  │  • ECR Endpoint               → Pull images without internet        │ │ │
│  │  └──────────────────────────────────────────────────────────────────────┘ │ │
│  │                                                                            │ │
│  └────────────────────────────────────────────────────────────────────────────┘ │
│                                                                                 │
│  ┌──────────────────────────────────────────────────────────────────────────┐ │
│  │              AWS SERVICES (Outside VPC)                                   │ │
│  │                                                                           │ │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐  ┌────────────┐        │ │
│  │  │    SQS     │  │    SNS     │  │  DynamoDB  │  │     S3     │        │ │
│  │  │            │  │            │  │            │  │            │        │ │
│  │  │  Accessed  │  │  Accessed  │  │  Accessed  │  │  Accessed  │        │ │
│  │  │  via NAT   │  │  via NAT   │  │  via VPC   │  │  via VPC   │        │ │
│  │  │  Gateway   │  │  Gateway   │  │  Endpoint  │  │  Endpoint  │        │ │
│  │  └────────────┘  └────────────┘  └────────────┘  └────────────┘        │ │
│  └──────────────────────────────────────────────────────────────────────────┘ │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘

SECURITY GROUPS CONFIGURATION:
═══════════════════════════════════════════════════════════════════════════════

┌─────────────────────────────────────────────────────────────────────────┐
│  Security Group: lambda-sg                                               │
│  Purpose: Lambda functions                                              │
│                                                                          │
│  Outbound Rules:                                                         │
│  • TCP 5432 → rds-sg (PostgreSQL)                    ✓                 │
│  • TCP 443 → 0.0.0.0/0 (HTTPS for AWS APIs)          ✓                 │
│  • All traffic → VPC Endpoints                        ✓                 │
│                                                                          │
│  Inbound Rules:                                                          │
│  • NONE (Lambda doesn't need inbound)                                   │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│  Security Group: rds-sg                                                  │
│  Purpose: RDS PostgreSQL                                                │
│                                                                          │
│  Inbound Rules:                                                          │
│  • TCP 5432 from lambda-sg                            ✓                 │
│  • Deny all other sources                             ✓                 │
│                                                                          │
│  Outbound Rules:                                                         │
│  • All traffic (for replication to standby)           ✓                 │
└─────────────────────────────────────────────────────────────────────────┘

NETWORK TRAFFIC FLOWS:
═══════════════════════════════════════════════════════════════════════════

Flow 1: Lambda → S3
  Lambda (10.0.10.5) → VPC S3 Endpoint → S3 Bucket
  [Private connection, no internet]

Flow 2: Lambda → DynamoDB
  Lambda (10.0.10.5) → VPC DynamoDB Endpoint → DynamoDB
  [Private connection, no internet]

Flow 3: Lambda → RDS
  Lambda (10.0.10.5) → RDS (10.0.10.100)
  [Direct VPC connection, security group enforced]

Flow 4: Lambda → Secrets Manager
  Lambda (10.0.10.5) → VPC Secrets Manager Endpoint → Secrets Manager
  [Private connection, no internet]

Flow 5: Lambda → SQS/SNS
  Lambda (10.0.10.5) → NAT Gateway (10.0.1.x) → Internet Gateway → SQS/SNS
  [Goes through NAT for internet access]

Flow 6: ECR Image Pull (Cold Start)
  Lambda → VPC ECR Endpoint → ECR
  [Private connection for pulling container images]
```

---

## 5. Event-Driven Flow

### Event Propagation Timeline
```
┌────────────────────────────────────────────────────────────────────────────────┐
│                        EVENT-DRIVEN FLOW TIMELINE                               │
└────────────────────────────────────────────────────────────────────────────────┘

TIME: T+0 seconds
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────┐
                    │    VENDOR    │
                    │  Uploads CSV │
                    └──────┬───────┘
                           │
                           │ HTTP PUT Request
                           │ Authorization: AWS4-HMAC-SHA256...
                           ↓
                    ┌──────────────┐
                    │   S3 BUCKET  │ ← Event: ObjectCreated:Put
                    └──────┬───────┘
                           │
                           │ Generates S3 Event
                           │
                    ┌──────▼───────────────────────────────────────┐
                    │  S3 Event Notification                       │
                    │  {                                            │
                    │    "Records": [{                             │
                    │      "eventName": "ObjectCreated:Put",       │
                    │      "s3": {                                 │
                    │        "bucket": {"name": "..."},            │
                    │        "object": {"key": "uploads/...csv"}   │
                    │      }                                        │
                    │    }]                                         │
                    │  }                                            │
                    └──────┬───────────────────────────────────────┘
                           │
                           │ Lambda Service receives event
                           │
TIME: T+0.1 seconds        ↓
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────┐
                    │  LAMBDA: csv-parser              │
                    │  Status: Invoked                 │
                    │                                  │
                    │  Cold Start:                     │
                    │  • Allocate execution environment│
                    │  • Pull container from ECR       │
                    │  • Initialize runtime            │
                    │  • Import modules                │
                    │                                  │
                    │  Duration: ~3 seconds            │
                    └──────────────────────────────────┘

TIME: T+3 seconds (Warm Lambda)
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────┐
                    │  LAMBDA: csv-parser              │
                    │  Status: Processing              │
                    │                                  │
                    │  Actions:                        │
                    │  1. Download CSV from S3         │
                    │  2. Parse 1000 rows              │
                    │  3. Batch insert DynamoDB        │
                    │                                  │
                    │  Duration: ~2.5 seconds          │
                    └────────┬─────────────────────────┘
                             │
                             │ BatchWriteItem (1000 items)
                             ↓
TIME: T+5.5 seconds
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────┐
                    │  DYNAMODB: UploadRecords         │ ← Event: 1000 INSERTs
                    │  1000 items inserted             │
                    └────────┬─────────────────────────┘
                             │
                             │ DynamoDB Streams capture changes
                             │
                    ┌────────▼─────────────────────────────────┐
                    │  DynamoDB Stream Records (1000)          │
                    │                                           │
                    │  Shard 1: Records 1-400   → Batch 1-4    │
                    │  Shard 2: Records 401-700 → Batch 5-7    │
                    │  Shard 3: Records 701-1000 → Batch 8-10  │
                    │                                           │
                    │  Event Source Mapping batches records    │
                    │  (100 per batch = 10 batches total)      │
                    └────────┬─────────────────────────────────┘
                             │
                             │ Parallel Lambda invocations
                             ↓
TIME: T+5.6 seconds
═══════════════════════════════════════════════════════════════════════════════
                    ┌────────────────────────────────────────┐
                    │  LAMBDA: product-validator             │
                    │  10 concurrent executions              │
                    │                                        │
                    │  Execution 1: Records 1-100            │
                    │  Execution 2: Records 101-200          │
                    │  ...                                   │
                    │  Execution 10: Records 901-1000        │
                    │                                        │
                    │  Each execution:                       │
                    │  • Validates 100 records               │
                    │  • Inserts valid → RDS                 │
                    │  • Sends invalid → SQS                 │
                    │  • Duration: ~4.5 seconds each         │
                    └────────┬───────────────────────────────┘
                             │
                             │ Results:
                             │ • 950 valid → RDS
                             │ • 50 errors → SQS
                             ↓
TIME: T+10 seconds
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────┐
                    │  SQS: product-validation-errors  │ ← Event: 50 messages
                    │  50 error messages queued        │
                    └────────┬─────────────────────────┘
                             │
                             │ Wait for batching window
                             │ (30 seconds max)
                             ↓
TIME: T+40 seconds (30s timeout)
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────┐
                    │  SQS Event Source Mapping        │
                    │                                  │
                    │  Batching:                       │
                    │  • Batch size: 10 messages       │
                    │  • Total messages: 50            │
                    │  • Lambda invocations: 5         │
                    └────────┬─────────────────────────┘
                             │
                             │ Invoke Lambda 5 times
                             ↓
TIME: T+40.1 seconds
═══════════════════════════════════════════════════════════════════════════════
                    ┌────────────────────────────────────────┐
                    │  LAMBDA: error-processor               │
                    │  5 concurrent executions               │
                    │                                        │
                    │  Execution 1: Messages 1-10            │
                    │  Execution 2: Messages 11-20           │
                    │  ...                                   │
                    │  Execution 5: Messages 41-50           │
                    │                                        │
                    │  Each execution:                       │
                    │  • Groups errors by upload_id          │
                    │  • Generates CSV chunk                 │
                    │  • Duration: ~0.5 seconds each         │
                    │                                        │
                    │  Final execution (when complete):      │
                    │  • Uploads error CSV to S3             │
                    │  • Triggers SNS                        │
                    └────────┬───────────────────────────────┘
                             │
                             │ Publish to SNS
                             ↓
TIME: T+41 seconds
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────────────────────────┐
                    │  SNS: Upload notifications       │ ← Event: Message published
                    └────────┬─────────────────────────┘
                             │
                             │ Deliver to subscriptions
                             ↓
TIME: T+42 seconds
═══════════════════════════════════════════════════════════════════════════════
                    ┌──────────────┐
                    │ EMAIL (SES)  │
                    │ Sent to:     │
                    │ • vendor@... │
                    │ • support@...│
                    └──────┬───────┘
                           │
                           ↓
                    ┌──────────────┐
                    │    VENDOR    │
                    │  Receives    │
                    │  Notification│
                    └──────────────┘

═══════════════════════════════════════════════════════════════════════════════
TOTAL ELAPSED TIME: ~42 seconds
FROM: CSV upload
TO: Vendor receives email notification

BREAKDOWN:
• T+0 to T+5.5s:  CSV parsing (5.5s)
• T+5.5 to T+10s: Validation (4.5s parallel)
• T+10 to T+40s:  SQS batching wait (30s)
• T+40 to T+42s:  Error processing + email (2s)
═══════════════════════════════════════════════════════════════════════════════
```

---

## 6. Database Architecture

### RDS PostgreSQL & DynamoDB Schema
```
┌────────────────────────────────────────────────────────────────────────────────┐
│                           DATABASE ARCHITECTURE                                 │
└────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│  RDS POSTGRESQL - PERMANENT CATALOG                                           │
│  ecommerce_platform database                                                  │
└──────────────────────────────────────────────────────────────────────────────┘

  ┌────────────────────────────────────────────────────────────────────┐
  │  TABLE: vendors                                                     │
  │  Purpose: Master vendor registry                                   │
  ├────────────────────────────────────────────────────────────────────┤
  │  vendor_id VARCHAR(50) PRIMARY KEY                                 │
  │  vendor_name VARCHAR(200) NOT NULL                                 │
  │  email VARCHAR(255) NOT NULL                                       │
  │  phone VARCHAR(20)                                                 │
  │  status VARCHAR(20) DEFAULT 'active'                               │
  │  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP                    │
  │                                                                     │
  │  Sample Data:                                                       │
  │  VEND001 | TechGear      | contact@techgear.com | active           │
  │  VEND002 | StyleWear     | sales@stylewear.com  | active           │
  │  VEND003 | HomeEssentials| info@homeess.com     | active           │
  └────────────────────────────────────────────────────────────────────┘
                 │ Referenced by
                 ↓
  ┌────────────────────────────────────────────────────────────────────┐
  │  TABLE: products                                                    │
  │  Purpose: Validated product catalog                                │
  ├────────────────────────────────────────────────────────────────────┤
  │  product_id SERIAL PRIMARY KEY                                     │
  │  vendor_id VARCHAR(50) REFERENCES vendors(vendor_id)               │
  │  vendor_product_id VARCHAR(100) NOT NULL                           │
  │  product_name VARCHAR(200) NOT NULL                                │
  │  category VARCHAR(100) NOT NULL                                    │
  │  subcategory VARCHAR(100)                                          │
  │  description TEXT                                                  │
  │  sku VARCHAR(100) UNIQUE NOT NULL                                  │
  │  brand VARCHAR(100)                                                │
  │  price DECIMAL(10,2) NOT NULL CHECK (price > 0)                    │
  │  compare_at_price DECIMAL(10,2)                                    │
  │  stock_quantity INTEGER NOT NULL CHECK (stock_quantity >= 0)       │
  │  unit VARCHAR(20) DEFAULT 'piece'                                  │
  │  weight_kg DECIMAL(10,3)                                           │
  │  dimensions_cm VARCHAR(50)                                         │
  │  image_url TEXT                                                    │
  │  upload_id VARCHAR(50)                                             │
  │  status VARCHAR(20) DEFAULT 'active'                               │
  │  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP                    │
  │  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP                    │
  │                                                                     │
  │  UNIQUE (vendor_id, vendor_product_id)                             │
  │                                                                     │
  │  Indexes:                                                           │
  │  • idx_vendor_id ON (vendor_id)                                    │
  │  • idx_category ON (category)                                      │
  │  • idx_upload_id ON (upload_id)                                    │
  │  • idx_sku ON (sku) [UNIQUE]                                       │
  └────────────────────────────────────────────────────────────────────┘

  ┌────────────────────────────────────────────────────────────────────┐
  │  TABLE: product_categories                                         │
  │  Purpose: Category whitelist for validation                        │
  ├────────────────────────────────────────────────────────────────────┤
  │  category_id SERIAL PRIMARY KEY                                    │
  │  category_name VARCHAR(100) UNIQUE NOT NULL                        │
  │  description TEXT                                                  │
  │  is_active BOOLEAN DEFAULT TRUE                                    │
  │  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP                    │
  │                                                                     │
  │  Sample Data:                                                       │
  │  1 | Electronics         | Electronic devices... | true            │
  │  2 | Computer Accessories| Peripherals...        | true            │
  │  3 | Clothing           | Apparel items...      | true            │
  └────────────────────────────────────────────────────────────────────┘

  ┌────────────────────────────────────────────────────────────────────┐
  │  TABLE: upload_history                                             │
  │  Purpose: Audit trail of all CSV uploads                           │
  ├────────────────────────────────────────────────────────────────────┤
  │  upload_id VARCHAR(50) PRIMARY KEY                                 │
  │  vendor_id VARCHAR(50) REFERENCES vendors(vendor_id)               │
  │  file_name VARCHAR(255) NOT NULL                                   │
  │  file_size_bytes BIGINT                                            │
  │  total_records INTEGER                                             │
  │  valid_records INTEGER DEFAULT 0                                   │
  │  error_records INTEGER DEFAULT 0                                   │
  │  status VARCHAR(20)                                                │
  │    ['processing', 'completed', 'partial', 'failed']                │
  │  error_file_s3_key VARCHAR(500)                                    │
  │  upload_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP              │
  │  processing_started_at TIMESTAMP                                   │
  │  processing_completed_at TIMESTAMP                                 │
  │                                                                     │
  │  Indexes:                                                           │
  │  • idx_vendor_upload ON (vendor_id, upload_timestamp DESC)         │
  │  • idx_status ON (status)                                          │
  └────────────────────────────────────────────────────────────────────┘

  ┌────────────────────────────────────────────────────────────────────┐
  │  TABLE: validation_errors                                          │
  │  Purpose: Detailed error tracking                                  │
  ├────────────────────────────────────────────────────────────────────┤
  │  error_id SERIAL PRIMARY KEY                                       │
  │  upload_id VARCHAR(50) REFERENCES upload_history(upload_id)        │
  │  vendor_id VARCHAR(50) REFERENCES vendors(vendor_id)               │
  │  row_number INTEGER NOT NULL                                       │
  │  vendor_product_id VARCHAR(100)                                    │
  │  error_type VARCHAR(50) NOT NULL                                   │
  │    ['MISSING_REQUIRED_FIELDS', 'INVALID_PRICE',                    │
  │     'INVALID_STOCK_QUANTITY', 'FIELD_LENGTH_EXCEEDED',             │
  │     'INVALID_CATEGORY', 'DUPLICATE_SKU',                           │
  │     'DUPLICATE_VENDOR_PRODUCT_ID']                                 │
  │  error_field VARCHAR(100)                                          │
  │  error_message TEXT NOT NULL                                       │
  │  original_data JSONB                                               │
  │  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP                    │
  │                                                                     │
  │  Indexes:                                                           │
  │  • idx_upload_errors ON (upload_id)                                │
  │  • idx_error_type ON (error_type)                                  │
  └────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────────────────┐
│  DYNAMODB - TEMPORARY STAGING                                                 │
│  UploadRecords table                                                          │
└──────────────────────────────────────────────────────────────────────────────┘

  ┌────────────────────────────────────────────────────────────────────┐
  │  TABLE: UploadRecords                                              │
  │  Purpose: Temporary staging during validation                      │
  ├────────────────────────────────────────────────────────────────────┤
  │  Partition Key: upload_id (String)                                 │
  │  Sort Key: record_id (String)                                      │
  │                                                                     │
  │  Attributes:                                                        │
  │  • vendor_id (String)                                              │
  │  • row_number (Number)                                             │
  │  • status (String)                                                 │
  │    ['pending_validation', 'validated', 'error']                    │
  │  • product_data (Map)                                              │
  │    {                                                                │
  │      vendor_product_id: String,                                    │
  │      product_name: String,                                         │
  │      category: String,                                             │
  │      sku: String,                                                  │
  │      price: Number,                                                │
  │      stock_quantity: Number,                                       │
  │      ...                                                            │
  │    }                                                                │
  │  • error_reason (String) [if status='error']                       │
  │  • error_details (String) [if status='error']                      │
  │  • created_at (String) [ISO 8601]                                  │
  │  • processed_at (String) [ISO 8601]                                │
  │                                                                     │
  │  Global Secondary Index: VendorIndex                               │
  │  • Partition Key: vendor_id                                        │
  │  • ProjectionType: ALL                                             │
  │                                                                     │
  │  DynamoDB Streams: ENABLED                                         │
  │  • StreamViewType: NEW_IMAGE                                       │
  │  • Retention: 24 hours                                             │
  │                                                                     │
  │  Sample Item:                                                       │
  │  {                                                                  │
  │    "upload_id": "UPLOAD_20241221_103045",                         │
  │    "record_id": "REC_00001",                                       │
  │    "vendor_id": "VEND001",                                         │
  │    "row_number": 1,                                                │
  │    "status": "validated",                                          │
  │    "product_data": {                                               │
  │      "vendor_product_id": "PROD0001",                              │
  │      "product_name": "Wireless Mouse",                             │
  │      "sku": "SKU-001",                                             │
  │      "price": 19.99,                                               │
  │      "stock_quantity": 150                                         │
  │    },                                                               │
  │    "created_at": "2024-12-21T10:30:45.123Z",                      │
  │    "processed_at": "2024-12-21T10:30:50.456Z"                     │
  │  }                                                                  │
  └────────────────────────────────────────────────────────────────────┘

DATA RELATIONSHIPS:
═══════════════════════════════════════════════════════════════════════════════

vendors (1) ──────────── (N) products
   │                          │
   │                          │
   └──── (N) upload_history   │
             │                │
             │                │
             └─ (N) validation_errors
```

---

## 7. Error Handling Architecture

### Multi-Layer Error Strategy
```
┌────────────────────────────────────────────────────────────────────────────────┐
│                       ERROR HANDLING ARCHITECTURE                               │
└────────────────────────────────────────────────────────────────────────────────┘

LAYER 1: PREVENTION (Validation Rules)
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  VALIDATOR LAMBDA                   │
                    │                                     │
                    │  7 Validation Rules:                │
                    │  ┌─────────────────────────────────┐│
                    │  │ 1. Required Fields              ││
                    │  │ 2. Price Range (0.01-999999.99) ││
                    │  │ 3. Stock Range (0-1000000)      ││
                    │  │ 4. Field Lengths                ││
                    │  │ 5. Category Whitelist           ││
                    │  │ 6. SKU Uniqueness               ││
                    │  │ 7. Vendor Product ID Uniqueness ││
                    │  └─────────────────────────────────┘│
                    │                                     │
                    │  Each rule prevents bad data        │
                    └─────────────────────────────────────┘

LAYER 2: DETECTION (Try-Catch Blocks)
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  ALL LAMBDA FUNCTIONS               │
                    │                                     │
                    │  try:                               │
                    │      # Risky operation              │
                    │      conn = psycopg2.connect(...)   │
                    │  except Exception as e:             │
                    │      logger.error(f"Error: {e}")    │
                    │      # Handle gracefully            │
                    │                                     │
                    │  Common exceptions:                 │
                    │  • psycopg2.OperationalError        │
                    │  • botocore.exceptions.ClientError  │
                    │  • KeyError, ValueError             │
                    └─────────────────────────────────────┘

LAYER 3: RECOVERY (Retry Logic)
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  LAMBDA AUTOMATIC RETRIES           │
                    │                                     │
                    │  Event Source Mappings:             │
                    │  • DynamoDB Streams: 10000 retries  │
                    │  • SQS: 3 retries                   │
                    │                                     │
                    │  Failed after retries?              │
                    │  ↓                                  │
                    │  DLQ (Dead-Letter Queue)            │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  DEAD-LETTER QUEUE                  │
                    │  product-validation-errors-dlq      │
                    │                                     │
                    │  Messages that failed all retries   │
                    │  • Manual review required           │
                    │  • CloudWatch Alarm triggered       │
                    └─────────────────────────────────────┘

LAYER 4: NOTIFICATION (Logging & Alerts)
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  CLOUDWATCH LOGS                    │
                    │                                     │
                    │  Every Lambda execution logged:     │
                    │  • INFO: Normal operations          │
                    │  • WARN: Recoverable issues         │
                    │  • ERROR: Failures                  │
                    │                                     │
                    │  /aws/lambda/csv-parser             │
                    │  /aws/lambda/product-validator      │
                    │  /aws/lambda/error-processor        │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  CLOUDWATCH METRICS                 │
                    │                                     │
                    │  Custom Metrics:                    │
                    │  • ProductsValidated                │
                    │  • ProductsRejected                 │
                    │  • ValidationProcessingTime         │
                    │  • ErrorsProcessed                  │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  CLOUDWATCH ALARMS                  │
                    │                                     │
                    │  Triggers on:                       │
                    │  • Error rate > 10%                 │
                    │  • Processing time > 5 min          │
                    │  • DLQ messages > 0                 │
                    │                                     │
                    │  Action: SNS notification to Ops    │
                    └─────────────────────────────────────┘

LAYER 5: AUDIT (Database Recording)
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  RDS: validation_errors TABLE       │
                    │                                     │
                    │  Every error recorded:              │
                    │  • upload_id                        │
                    │  • row_number                       │
                    │  • error_type                       │
                    │  • error_message                    │
                    │  • original_data (JSONB)            │
                    │  • timestamp                        │
                    │                                     │
                    │  Queryable for:                     │
                    │  • Trend analysis                   │
                    │  • Vendor reports                   │
                    │  • Compliance audits                │
                    └─────────────────────────────────────┘

ERROR FLOW EXAMPLE:
═══════════════════════════════════════════════════════════════════════════════

Product with Duplicate SKU:
    ↓
Layer 1: Validator detects duplicate
    ├─ Query: SELECT * FROM products WHERE sku='SKU-001'
    └─ Result: 1 row found → DUPLICATE!
    ↓
Layer 2: Error caught and handled
    ├─ No exception thrown (controlled)
    └─ Create error record
    ↓
Layer 3: No retry needed (expected error)
    ↓
Layer 4: Log error + Send metric
    ├─ CloudWatch Log: "Duplicate SKU detected: SKU-001"
    └─ Metric: ProductsRejected +1
    ↓
Layer 5: Record in database
    ├─ INSERT INTO validation_errors
    ├─ UPDATE DynamoDB status='error'
    └─ SEND to SQS error queue
    ↓
Vendor receives error CSV with details ✓
```

---

## 8. Security Architecture

### Defense in Depth
```
┌────────────────────────────────────────────────────────────────────────────────┐
│                          SECURITY ARCHITECTURE                                  │
└────────────────────────────────────────────────────────────────────────────────┘

LAYER 1: NETWORK SECURITY
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  VPC ISOLATION                      │
                    │                                     │
                    │  • Private subnets for RDS          │
                    │  • Lambda in VPC (access to RDS)    │
                    │  • No public internet access        │
                    │  • NAT Gateway for AWS APIs only    │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  SECURITY GROUPS                    │
                    │                                     │
                    │  lambda-sg:                         │
                    │  • Outbound: 5432 → rds-sg only     │
                    │  • Outbound: 443 → AWS APIs         │
                    │  • Inbound: NONE                    │
                    │                                     │
                    │  rds-sg:                            │
                    │  • Inbound: 5432 from lambda-sg     │
                    │  • Inbound: Deny all else           │
                    └─────────────────────────────────────┘

LAYER 2: IDENTITY & ACCESS (IAM)
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  IAM ROLES (Least Privilege)        │
                    │                                     │
                    │  csv-parser-role:                   │
                    │  • s3:GetObject (uploads/* only)    │
                    │  • dynamodb:BatchWriteItem          │
                    │  • rds:* (specific DB only)         │
                    │  • secretsmanager:GetSecretValue    │
                    │  • logs:*                           │
                    │                                     │
                    │  product-validator-role:            │
                    │  • dynamodb:GetRecords (streams)    │
                    │  • dynamodb:UpdateItem              │
                    │  • rds:*                            │
                    │  • sqs:SendMessage                  │
                    │  • secretsmanager:GetSecretValue    │
                    │  • logs:*                           │
                    │                                     │
                    │  error-processor-role:              │
                    │  • sqs:ReceiveMessage               │
                    │  • sqs:DeleteMessage                │
                    │  • s3:PutObject (errors/* only)     │
                    │  • sns:Publish                      │
                    │  • rds:*                            │
                    │  • secretsmanager:GetSecretValue    │
                    │  • logs:*                           │
                    └─────────────────────────────────────┘

LAYER 3: DATA PROTECTION (Encryption)
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  ENCRYPTION AT REST                 │
                    │                                     │
                    │  S3:                                │
                    │  • AES-256 server-side encryption   │
                    │  • Bucket-level encryption          │
                    │                                     │
                    │  RDS:                               │
                    │  • Encrypted storage volumes        │
                    │  • Automated backups encrypted      │
                    │                                     │
                    │  DynamoDB:                          │
                    │  • Encryption enabled (default)     │
                    │                                     │
                    │  Secrets Manager:                   │
                    │  • KMS encryption (CMK)             │
                    │  • Encrypted in transit and at rest │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  ENCRYPTION IN TRANSIT              │
                    │                                     │
                    │  • All AWS API calls: HTTPS (TLS)   │
                    │  • Lambda → RDS: TLS supported      │
                    │  • S3 uploads: HTTPS required       │
                    │  • SNS emails: TLS                  │
                    └─────────────────────────────────────┘

LAYER 4: SECRET MANAGEMENT
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  SECRETS MANAGER                    │
                    │                                     │
                    │  ecommerce/rds/credentials          │
                    │  {                                  │
                    │    "username": "postgres",          │
                    │    "password": "***",               │
                    │    "host": "ecommerce-db.xxx",      │
                    │    "port": 5432,                    │
                    │    "dbname": "ecommerce_platform"   │
                    │  }                                  │
                    │                                     │
                    │  Features:                          │
                    │  • KMS encryption                   │
                    │  • Automatic rotation               │
                    │  • Versioning                       │
                    │  • Audit trail (CloudTrail)         │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  LAMBDA CACHING                     │
                    │                                     │
                    │  Client-side cache:                 │
                    │  • TTL: 1 hour                      │
                    │  • Reused across invocations        │
                    │  • Reduces API calls (cost + perf)  │
                    │                                     │
                    │  Cache miss: ~50ms (API call)       │
                    │  Cache hit: <1ms (in-memory)        │
                    └─────────────────────────────────────┘

LAYER 5: AUDIT & COMPLIANCE
═══════════════════════════════════════════════════════════════════════════════
                    ┌─────────────────────────────────────┐
                    │  CLOUDWATCH LOGS                    │
                    │                                     │
                    │  Every operation logged:            │
                    │  • Lambda executions                │
                    │  • API calls (via CloudTrail)       │
                    │  • Database queries                 │
                    │  • Error events                     │
                    │                                     │
                    │  Retention: 30 days (configurable)  │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  RDS AUDIT TRAIL                    │
                    │                                     │
                    │  upload_history table:              │
                    │  • Every upload tracked             │
                    │  • Timestamps recorded              │
                    │  • Results logged                   │
                    │                                     │
                    │  validation_errors table:           │
                    │  • Every error logged               │
                    │  • Original data preserved (JSONB)  │
                    │  • Queryable for compliance         │
                    └─────────────────────────────────────┘
                             │
                             ↓
                    ┌─────────────────────────────────────┐
                    │  AWS CLOUDTRAIL                     │
                    │                                     │
                    │  Tracks:                            │
                    │  • IAM role assumptions             │
                    │  • AWS API calls                    │
                    │  • Resource modifications           │
                    │  • Who did what when                │
                    │                                     │
                    │  Retention: 90 days                 │
                    └─────────────────────────────────────┘

SECURITY CHECKLIST:
═══════════════════════════════════════════════════════════════════════════════
✓ No hardcoded credentials
✓ Secrets in Secrets Manager
✓ Least privilege IAM roles
✓ RDS not publicly accessible
✓ Lambda in VPC
✓ Security groups properly configured
✓ All data encrypted at rest
✓ All traffic encrypted in transit
✓ Complete audit trail
✓ CloudWatch monitoring enabled
✓ Automatic backups configured
✓ Multi-AZ deployment (RDS)
✓ Presigned URLs time-limited (7 days)
```

---

## Summary

This architecture diagram document provides:

1. ✅ **High-Level Architecture** - Bird's eye view
2. ✅ **Detailed Components** - Every AWS service shown
3. ✅ **Data Flow** - Complete journey from upload to email
4. ✅ **Network Architecture** - VPC, subnets, security groups
5. ✅ **Event-Driven Flow** - Timeline with exact timing
6. ✅ **Database Architecture** - Schema with relationships
7. ✅ **Error Handling** - Multi-layer strategy
8. ✅ **Security Architecture** - Defense in depth

**Perfect for:**
- 📚 Student learning
- 👨‍🏫 Teaching presentations
- 📊 Documentation
- 🔍 System understanding
- 🐛 Troubleshooting
- 💼 Portfolio demonstrations

**Use these diagrams to:**
- Explain system design decisions
- Understand data flow
- Troubleshoot issues
- Plan extensions
- Present to stakeholders
